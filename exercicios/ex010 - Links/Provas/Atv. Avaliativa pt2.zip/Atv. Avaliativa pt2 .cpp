#include <iostream>

using namespace std;
//Difinir o tamanho máximo da pilha
#define TAM 5

//Definindo as variáveis 
int main() {
  int pilha[TAM], fim = 0, topo = -1, op = 0, push , i = 0, fila[TAM], j = 0; 

  do {
    //Sistema de menu
    cout << "\tM E N U  " << endl;
    cout << "Escolha uma opção:" << endl;
    cout << "(1) PUSH" << endl;
    cout << "(2) POP" << endl;
    cout << "(3) Inverter" << endl;
    cout << "(4) Imprimir" << endl;
    cout << "(9) Sair" << endl;
    cin >> op;


    switch(op){

      case 1:
      
        
        //Checagem da pilha
        if (topo < TAM - 1){
          topo++;
          cout << "Digite um numero para inserir: " <<endl;
          cin >> push;
        //Sistema para inserir número na pilha  
          pilha[topo] = push; 
        }else 
        cout << "FILA CHEIA!!!"<<endl;

      break;
      
      case 2:
        //checagem para verificar se tem número na pilha
        if(topo >= 0){
          //Sistema para remover números da pilha
          for(i = 0; i < topo; i++){
            pilha[i] = pilha[i + 1];
          }
          topo--;
        }
        else
          cout << "Não tem números para remover!!!" << endl;

        system("pause");

      break;
      
      case 3:
         if(topo >= 0){
          //Sistema de inversão da pilha
          for(i = topo; i >= 0; i--){
            //Passando os números da pilha para uma fila
            fila[j] = pilha[i];
            j++;
          }
        }
        else
          cout << "A pilha está vazia" << endl;

        for(i = 0; i <= topo; i++){
          //Passando os números da fila para uma pilha (inverso)
          pilha[i] = fila[i];
        }
  
        
      break;
    
      case 4:

        cout << "Imprimindo Pilha!!!"<<endl<<endl;
    
        
        if (topo >= 0){
          //Sistema da impressão da pilha
          for(i = 0; i <= topo; i++){
            cout << pilha[i] << endl;
          }
        } else 
          cout << "Não tem número na Pilha" <<endl;
        
      break;

      case 9:
        
        
        cout << "Saindo!!!";
      
      return 0;
  
    }

  } while(op != 9);

  return 0;
}